package ca.mcgill.ecse211;

public class LightLocalizer {

}
